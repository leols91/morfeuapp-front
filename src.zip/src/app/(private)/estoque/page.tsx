export default function EstoquePage() {
  return <div>Estoque — em breve</div>;
}

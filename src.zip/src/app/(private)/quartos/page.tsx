export default function QuartosPage() {
  return <div>Quartos — em breve</div>;
}

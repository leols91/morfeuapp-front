export default function HospedesPage() {
  return <div>Hospedes — em breve</div>;
}

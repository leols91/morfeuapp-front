export default function FinanceiroPage() {
  return <div>Financeiro — em breve</div>;
}

export default function ConfiguracoesPage() {
  return <div>Configuracoes — em breve</div>;
}
